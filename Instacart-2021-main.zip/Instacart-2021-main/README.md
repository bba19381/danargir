# Instacart-2021

This is the 2021 version of the notebook created by the Information Systems Lab to introduce students of the University of Macedonia, Greece to Machine Learning & Data Science.

The notebook has been created to use in a RAPIDS environment. In particular in has been developed in a 16 vCPUs, 6O GB RAM, and 1 NVIDIA Tesla T4 GPU in Google Cloud Platform.
